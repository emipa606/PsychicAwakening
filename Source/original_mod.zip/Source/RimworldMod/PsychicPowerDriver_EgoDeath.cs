﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RimWorld
{
    class PsychicPowerDriver_EgoDeath : PsychicPowerDriver
    {
        List<TraitDef> physicalTraits = new List<TraitDef> { TraitDefOf.Beauty, TraitDefOf.Tough, TraitDef.Named("Immunity")};

        public override void UsePower(PsychicPowerDef power, Pawn user, Pawn target)
        {
            if (target.needs.mood != null)
            {
                Thought_Memory theThought = (Thought_Memory)ThoughtMaker.MakeThought(power.thought);
                theThought.age = (int)((float)theThought.def.DurationTicks * (1 - (user.GetStatValue(StatDefOf.PsychicSensitivity) * target.GetStatValue(StatDefOf.PsychicSensitivity))));
                theThought.moodPowerFactor = user.GetStatValue(StatDefOf.PsychicSensitivity) * target.GetStatValue(StatDefOf.PsychicSensitivity);
                target.needs.mood.thoughts.memories.TryGainMemory(theThought, user);
            }
            if (target.RaceProps.Humanlike)
            {
                List<Trait> toReplace = new List<Trait>();
                foreach(Trait t in target.story.traits.allTraits)
                {
                    if(!physicalTraits.Contains(t.def))
                    {
                        toReplace.Add(t);
                    }
                }
                foreach(Trait t in toReplace)
                {
                    target.story.traits.allTraits.Remove(t);
                }
                int newTraitNum = Math.Min(Rand.RangeInclusive(1, 3), 3 - target.story.traits.allTraits.Count);
                for (int i=0;i<newTraitNum;i++)
                {
                    target.story.traits.GainTrait(RandomMentalTrait(target));
                }
            }
            else
            {
                if(Rand.Chance(0.6f))
                {
                    target.health.AddHediff(HediffDefOf.MissingBodyPart, target.RaceProps.body.GetPartsWithTag(BodyPartTagDefOf.ConsciousnessSource).First());
                }
                else
                {
                    user.relations.AddDirectRelation(PawnRelationDefOf.Bond, target);
                    InteractionWorker_RecruitAttempt.DoRecruit(user, target, 1f, false);
                    if (user.Faction == Faction.OfPlayer || target.Faction == Faction.OfPlayer)
                    {
                        TaleRecorder.RecordTale(TaleDefOf.BondedWithAnimal, new object[]
                        {
                            user,
                            target
                        });
                    }
                    bool flag = false;
                    string value = null;
                    if (target.Name == null || target.Name.Numerical)
                    {
                        flag = true;
                        value = ((target.Name != null) ? target.Name.ToStringFull : target.LabelIndefinite());
                        target.Name = PawnBioAndNameGenerator.GeneratePawnName(target, NameStyle.Full, null);
                    }
                    if (PawnUtility.ShouldSendNotificationAbout(user) || PawnUtility.ShouldSendNotificationAbout(target))
                    {
                        string text;
                        if (flag)
                        {
                            text = "MessageNewBondRelationNewName".Translate(user.LabelShort, value, target.Name.ToStringFull, user.Named("HUMAN"), target.Named("ANIMAL")).AdjustedFor(target, "PAWN").CapitalizeFirst();
                        }
                        else
                        {
                            text = "MessageNewBondRelation".Translate(user.LabelShort, target.LabelShort, user.Named("HUMAN"), target.Named("ANIMAL")).CapitalizeFirst();
                        }
                        Messages.Message(text, user, MessageTypeDefOf.PositiveEvent, true);
                    }
                }
            }
        }

        private Trait RandomMentalTrait(Pawn target)
        {
            TraitDef def = DefDatabase<TraitDef>.GetRandom();
            if (target.story.traits.HasTrait(def) || physicalTraits.Contains(def))
                return RandomMentalTrait(target);
            if(def.degreeDatas != null)
                return new Trait(def, def.degreeDatas.RandomElement().degree, true);
            return new Trait(def, forced: true);
        }
    }
}
