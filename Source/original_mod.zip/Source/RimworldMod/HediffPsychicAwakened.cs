﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RimWorld
{
    public class HediffPsychicAwakened : HediffWithComps
    {
        public List<PsychicPowerDef> powersKnown;
        public PsychicPowerDef currentPower;

        public override void PostMake()
        {
            base.PostMake();
            powersKnown = new List<PsychicPowerDef>();
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look<PsychicPowerDef>(ref powersKnown,"powers");
            Scribe_Defs.Look<PsychicPowerDef>(ref currentPower, "currentPower");
        }
    }
}
