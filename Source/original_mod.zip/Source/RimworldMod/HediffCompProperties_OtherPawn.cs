﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RimWorld
{
    class HediffCompProperties_OtherPawn : HediffCompProperties
    {
        public HediffCompProperties_OtherPawn()
        {
            this.compClass = typeof(HediffComp_OtherPawn);
        }
    }
}
