﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RimWorld
{
    class PsychicPowerDriver_Siren : PsychicPowerDriver
    {
        public override void UsePower(PsychicPowerDef power, Pawn user, Pawn target)
        {
            IncidentParms raidParms = StorytellerUtility.DefaultParmsNow(IncidentCategoryDefOf.ThreatBig, user.Map);
            raidParms.forced = true;
            QueuedIncident qi = new QueuedIncident(new FiringIncident(IncidentDef.Named("RaidFriendlySiren"), null, raidParms), Find.TickManager.TicksGame + 30, 0);
            Find.Storyteller.incidentQueue.Add(qi);
        }
    }
}
