﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RimWorld
{
    public class CompPsychicEngram : CompUsable
    {
        public PsychicPowerDef power;

        protected override string FloatMenuOptionLabel(Pawn pawn)
        {
            return string.Format(base.Props.useLabel, this.power.label);
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Defs.Look<PsychicPowerDef>(ref this.power, "power");
        }

        public override void Initialize(CompProperties props)
        {
            base.Initialize(props);
            this.power = DefDatabase<PsychicPowerDef>.GetRandom();
        }

        public override string TransformLabel(string label)
        {
            return this.power.LabelCap + " " + label;
        }

        public override bool AllowStackWith(Thing other)
        {
            if (!base.AllowStackWith(other))
            {
                return false;
            }
            CompPsychicEngram compPsychicEngram = other.TryGetComp<CompPsychicEngram>();
            return compPsychicEngram != null && compPsychicEngram.power == this.power;
        }

        public override void PostSplitOff(Thing piece)
        {
            base.PostSplitOff(piece);
            CompPsychicEngram compPsychicEngram = piece.TryGetComp<CompPsychicEngram>();
            if (compPsychicEngram != null)
            {
                compPsychicEngram.power = this.power;
            }
        }

        public override string GetDescriptionPart()
        {
            return power.LabelCap+": "+power.description;
        }
    }
}
