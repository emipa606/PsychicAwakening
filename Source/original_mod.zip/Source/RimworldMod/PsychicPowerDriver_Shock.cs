﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RimWorld
{
    class PsychicPowerDriver_Shock : PsychicPowerDriver
    {
        public override void UsePower(PsychicPowerDef power, Pawn user, Pawn target)
        {
            if (Rand.Chance(0.4f))
            {
                if (target.Dead)
                    return;
                Hediff hediff = HediffMaker.MakeHediff(HediffDefOf.PsychicShock, target, null);
                BodyPartRecord part = null;
                target.RaceProps.body.GetPartsWithTag(BodyPartTagDefOf.ConsciousnessSource).TryRandomElement(out part);
                target.health.AddHediff(hediff, part, null, null);
                if (Rand.Chance(0.25f))
                {
                    BodyPartRecord brain = target.health.hediffSet.GetBrain();
                    if (brain == null)
                        return;
                    int num = Rand.RangeInclusive(1, 2);
                    DamageDef flame = DamageDefOf.Flame;
                    float amount = (float)num;
                    target.TakeDamage(new DamageInfo(flame, amount, 1f, -1f, user, brain, null, DamageInfo.SourceCategory.ThingOrUnknown, null));
                }
            }
            else
            {
                if (target.needs.mood != null)
                {
                    Thought_Memory theThought = (Thought_Memory)ThoughtMaker.MakeThought(power.thought);
                    theThought.age = (int)((float)theThought.def.DurationTicks * (1 - (user.GetStatValue(StatDefOf.PsychicSensitivity) * target.GetStatValue(StatDefOf.PsychicSensitivity))));
                    theThought.moodPowerFactor = user.GetStatValue(StatDefOf.PsychicSensitivity) * target.GetStatValue(StatDefOf.PsychicSensitivity);
                    target.needs.mood.thoughts.memories.TryGainMemory(theThought, user);
                }
                Hediff theHediff = HediffMaker.MakeHediff(power.hediff, target);
                theHediff.Severity = user.GetStatValue(StatDefOf.PsychicSensitivity) * target.GetStatValue(StatDefOf.PsychicSensitivity);
                target.health.AddHediff(theHediff);
            }
        }
    }
}
