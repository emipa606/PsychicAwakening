﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RimWorld
{
    public abstract class PsychicPowerDriver
    {
        public abstract void UsePower(PsychicPowerDef power, Pawn user, Pawn target);
    }
}
