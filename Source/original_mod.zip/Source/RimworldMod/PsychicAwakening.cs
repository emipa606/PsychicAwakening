﻿using HarmonyLib;
using HugsLib;
using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;
using Verse;
using Verse.AI;

namespace RimWorld
{
    public class PsychicMod : ModBase
    {
        public override string ModIdentifier
        {
            get
            {
                return "PsychicAwakening";
            }
        }

        public static bool knowsPower(Pawn p, PsychicPowerDef power)
        {
            HediffPsychicAwakened psychic = (HediffPsychicAwakened)p.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("PsychicAwakened"));
            return psychic != null && psychic.powersKnown.Contains(power);
        }

        public static Gizmo generateGizmo(HediffPsychicAwakened psychic, PsychicPowerDef power)
        {
            Command giz;
            if(power.target == PsychicTargetType.Pawn)
            {
                giz = new Command_Target();
                TargetingParameters parms = new TargetingParameters();
                parms.canTargetBuildings = false;
                parms.canTargetFires = false;
                parms.canTargetItems = false;
                parms.canTargetLocations = false;
                parms.canTargetPawns = true;
                parms.canTargetSelf = true;
                parms.validator = delegate (TargetInfo targ)
                {
                    if (!targ.HasThing)
                        return false;
                    return targ.Thing.GetStatValue(StatDefOf.PsychicSensitivity) > 0;
                };
                ((Command_Target)giz).targetingParams = parms;
                ((Command_Target)giz).action = delegate (Thing target)
                {
                    Job theJob = new Job(DefDatabase<JobDef>.GetNamed("UsePsychicPower"),target);
                    psychic.currentPower = power;
                    psychic.pawn.jobs.StartJob(theJob);
                };
            }
            else if (power.target == PsychicTargetType.DownedPawn)
            {
                giz = new Command_Target();
                ((Command_Target)giz).targetingParams = TargetingParameters.ForRescue(psychic.pawn);
                ((Command_Target)giz).targetingParams.validator = delegate (TargetInfo targ)
                {
                    if (!targ.HasThing)
                        return false;
                    return targ.Thing.GetStatValue(StatDefOf.PsychicSensitivity) > 0;
                };
                ((Command_Target)giz).action = delegate (Thing target)
                {
                    Job theJob = new Job(DefDatabase<JobDef>.GetNamed("UsePsychicPower"), target);
                    psychic.currentPower = power;
                    psychic.pawn.jobs.StartJob(theJob);
                };
            }
            else if (power.target == PsychicTargetType.PawnHumanlike)
            {
                giz = new Command_Target();
                TargetingParameters parms = new TargetingParameters();
                parms.canTargetBuildings = false;
                parms.canTargetFires = false;
                parms.canTargetItems = false;
                parms.canTargetLocations = false;
                parms.canTargetPawns = true;
                parms.canTargetSelf = true;
                parms.validator = delegate (TargetInfo targ)
                {
                    if (!targ.HasThing)
                        return false;
                    Pawn pawn = targ.Thing as Pawn;
                    return pawn != null && pawn.RaceProps.Humanlike && pawn.GetStatValue(StatDefOf.PsychicSensitivity) > 0;
                };
                ((Command_Target)giz).targetingParams = parms;
                ((Command_Target)giz).action = delegate (Thing target)
                {
                    Job theJob = new Job(DefDatabase<JobDef>.GetNamed("UsePsychicPower"), target);
                    psychic.currentPower = power;
                    psychic.pawn.jobs.StartJob(theJob);
                };
            }
            else if (power.target == PsychicTargetType.PawnOtherFaction)
            {
                giz = new Command_Target();
                TargetingParameters parms = new TargetingParameters();
                parms.canTargetBuildings = false;
                parms.canTargetFires = false;
                parms.canTargetItems = false;
                parms.canTargetLocations = false;
                parms.canTargetPawns = true;
                parms.canTargetSelf = true;
                parms.validator = delegate (TargetInfo targ)
                {
                    if (!targ.HasThing)
                        return false;
                    return targ.Thing.Faction != psychic.pawn.Faction && targ.Thing.GetStatValue(StatDefOf.PsychicSensitivity) > 0;
                };
                ((Command_Target)giz).targetingParams = parms;
                ((Command_Target)giz).action = delegate (Thing target)
                {
                    Job theJob = new Job(DefDatabase<JobDef>.GetNamed("UsePsychicPower"), target);
                    psychic.currentPower = power;
                    psychic.pawn.jobs.StartJob(theJob);
                };
            }
            else //if(power.target == PsychicTargetType.Self)
            {
                giz = new Command_Action();
                ((Command_Action)giz).action = delegate ()
                {
                    Job theJob = new Job(DefDatabase<JobDef>.GetNamed("UsePsychicPower"), psychic.pawn);
                    psychic.currentPower = power;
                    psychic.pawn.jobs.StartJob(theJob);
                };
            }
            giz.icon = power.Icon;
            giz.defaultDesc = power.description+"\n\nBurnout cost: "+(power.brainBurnCost * 100)+"%";
            giz.defaultLabel = power.LabelCap;
            return giz;
        }

        public static void addBrainBurn(Pawn user, PsychicPowerDef power)
        {
            LessonAutoActivator.TeachOpportunity(ConceptDef.Named("PsychicBrainBurn"), OpportunityType.Critical);
            BodyPartRecord brain = user.RaceProps.body.GetPartsWithTag(BodyPartTagDefOf.ConsciousnessSource).First();
            Hediff burn = user.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("PsychicBrainBurn"));
            if (burn != null)
            {
                burn.Severity = burn.Severity + (power.brainBurnCost * (1.2f-(0.025f*user.GetStatValue(StatDefOf.PsychicEntropyRecoveryRate))));
            }
            else
            {
                burn = HediffMaker.MakeHediff(HediffDef.Named("PsychicBrainBurn"), user, brain);
                burn.Severity = power.brainBurnCost * (1.2f - (0.025f * user.GetStatValue(StatDefOf.PsychicEntropyRecoveryRate)));
                user.health.AddHediff(burn);
            }

            if(burn.Severity >= 1)
            {
                GenExplosion.DoExplosion(user.Position, user.Map, 2, DamageDefOf.Flame, user, damAmount: 10, chanceToStartFire: 0.5f);
                if (brain.parent != null)
                    brain = brain.parent.parent;
                user.health.AddHediff(HediffDefOf.MissingBodyPart, brain);
                Messages.Message("PsychicHeadASplode".Translate(user.LabelShort), user, MessageTypeDefOf.NegativeHealthEvent, true);
            }
        }
    }

    [HarmonyPatch(typeof(Pawn), "GetGizmos")]
    public class PsychicPowerGizmos
    {
        [HarmonyPostfix]
        public static void GetAllTheGizmos(Pawn __instance, ref IEnumerable<Gizmo> __result)
        {
            if (__instance.IsColonistPlayerControlled)
            {
                HediffPsychicAwakened psychic = (HediffPsychicAwakened)__instance.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("PsychicAwakened"));
                if(psychic!=null)
                {
                    List<Gizmo> newList = new List<Gizmo>();
                    foreach (Gizmo g in __result)
                    {
                        newList.Add(g);
                    }

                    foreach(PsychicPowerDef power in psychic.powersKnown)
                    {
                        newList.Add(PsychicMod.generateGizmo(psychic, power));
                    }

                    __result = newList;
                }
            }
        }
    }

    [HarmonyPatch(typeof(Pawn_MindState), "CheckStartMentalStateBecauseRecruitAttempted")]
    public static class NoManhuntersPlease
    {
        [HarmonyPrefix]
        public static bool AffinityInterrupts(Pawn_MindState __instance)
        {
            return !__instance.pawn.health.hediffSet.HasHediff(HediffDef.Named("PsychicPowerAffinity"));
        }

        [HarmonyPostfix]
        public static void AffinityPrevents(Pawn_MindState __instance, ref bool __result)
        {
            if (__instance.pawn.health.hediffSet.HasHediff(HediffDef.Named("PsychicPowerAffinity")))
                __result = false;
        }
    }

    [HarmonyPatch(typeof(Pawn_RelationsTracker), "DirectRelationExists")]
    public static class AffinityFakeBond
    {
        [HarmonyPostfix]
        public static void FakeBond(PawnRelationDef def, Pawn otherPawn, ref bool __result)
        {
            if(def == PawnRelationDefOf.Bond && otherPawn.health.hediffSet.HasHediff(HediffDef.Named("PsychicPowerAffinity")))
            {
                __result = true;
            }
        }
    }

    [HarmonyPatch(typeof(IncidentWorker), "TryExecute")]
    public static class InterceptIncident
    {
        static bool premonitionActive = false;

        [HarmonyPrefix]
        public static bool Intercept(IncidentParms parms, IncidentWorker __instance)
        {
            premonitionActive = false;
            if (parms.forced)
                return true;
            foreach (Pawn pawn in PawnsFinder.AllMapsCaravansAndTravelingTransportPods_Alive_Colonists)
            {
                if (pawn.health.hediffSet.HasHediff(HediffDef.Named("PsychicPowerPremonition")))
                {
                    premonitionActive = true;
                    break;
                }
            }
            if (!__instance.CanFireNow(parms, true))
                premonitionActive = false;
            if(premonitionActive)
            {
                parms.forced = true;
                int delay = Rand.Range(2500, 20000);
                FiringIncident firingIncident = new FiringIncident(__instance.def, null, parms);
                if (firingIncident.parms.target == null)
                    firingIncident.parms.target = Find.Maps.First();
                QueuedIncident queuedIncident = new QueuedIncident(firingIncident, Find.TickManager.TicksGame + delay);
                Find.Storyteller.incidentQueue.Add(queuedIncident);
                Find.LetterStack.ReceiveLetter("Premonition", "A colonist's premonitions have become clear! The next " + __instance.def.label + " event will occur in approximately " + (int)Math.Round((float)(delay / 2500)) + " hours.", LetterDefOf.NeutralEvent);
            }
            return !premonitionActive;
        }

        [HarmonyPostfix]
        public static void ReturnTrue(ref bool __result)
        {
            if (premonitionActive)
                __result = true;
        }
    }

    [HarmonyPatch(typeof(Storyteller), "TryFire")]
    public static class FixPremonitionBug
    {
        [HarmonyPrefix]
        public static void fakeTarget(FiringIncident fi)
        {
            if (fi.parms.target == null)
                fi.parms.target = Find.World;
        }
    }

    [HarmonyPatch(typeof(SkillRecord))]
    [HarmonyPatch("Level",MethodType.Getter)]
    public static class UnitySkills
    {
        [HarmonyPostfix]
        public static void UseHigherLevel(SkillRecord __instance, ref int __result)
        {
            Pawn pawn = (Pawn)typeof(SkillRecord).GetField("pawn", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(__instance);
            if (pawn.health.hediffSet.HasHediff(HediffDef.Named("PsychicPowerUnity")))
            {
                HediffComp_OtherPawn comp = pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("PsychicPowerUnity")).TryGetComp<HediffComp_OtherPawn>();
                if(comp != null)
                {
                    Pawn other = comp.otherPawn;
                    if(other.skills != null && other.skills.GetSkill(__instance.def).levelInt > __result)
                    {
                        __result = other.skills.GetSkill(__instance.def).levelInt;
                    }
                }
            }
        }
    }

    [HarmonyPatch(typeof(SkillRecord),"Learn")]
    public static class UnityLearning
    {
        [HarmonyPostfix]
        public static void BothGainXP(SkillRecord __instance, float xp, bool direct)
        {
            if(!direct && xp > 0)
            {
                Pawn pawn = (Pawn)typeof(SkillRecord).GetField("pawn", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(__instance);
                if (pawn.health.hediffSet.HasHediff(HediffDef.Named("PsychicPowerUnity")))
                {
                    HediffComp_OtherPawn comp = pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("PsychicPowerUnity")).TryGetComp<HediffComp_OtherPawn>();
                    if (comp != null)
                    {
                        Pawn other = comp.otherPawn;
                        if (other.skills != null)
                        {
                            other.skills.Learn(__instance.def, xp, true);
                        }
                    }
                }
            }
        }
    }

    //TODO add "cast powers on schedule" like drug policy
}