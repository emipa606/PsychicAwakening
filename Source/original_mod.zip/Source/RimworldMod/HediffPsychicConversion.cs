﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RimWorld
{
    class HediffPsychicConversion : HediffWithComps
    {
        public override void Tick()
        {
            base.Tick();
            if(this.Severity >= 1)
            {
                Messages.Message("PsychicAwakeningComplete".Translate(this.pawn.LabelShort), this.pawn,MessageTypeDefOf.PositiveEvent, true);
                this.pawn.health.AddHediff(HediffDef.Named("PsychicAwakened"), this.pawn.RaceProps.body.GetPartsWithTag(BodyPartTagDefOf.ConsciousnessSource).First());
                HediffPsychicAwakened psychic = (HediffPsychicAwakened)this.pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("PsychicAwakened"));
                if(psychic != null)
                {
                    psychic.powersKnown.Add(DefDatabase<PsychicPowerDef>.GetRandom());
                }
                this.pawn.health.RemoveHediff(this);
                LessonAutoActivator.TeachOpportunity(ConceptDef.Named("PsychicAwakened"), OpportunityType.Critical);
            }
        }
    }
}
