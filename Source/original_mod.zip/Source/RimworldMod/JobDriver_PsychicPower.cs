﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;
using Verse.AI;
using Verse.Sound;

namespace RimWorld
{
    class JobDriver_PsychicPower : JobDriver
    {
        float workDone;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return true;
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            if (TargetA != LocalTargetInfo.Invalid)
                this.FailOnDespawnedOrNull(TargetIndex.A);
            Toil usePower = Toils_General.Wait(100, TargetIndex.A);
            usePower.defaultCompleteMode = ToilCompleteMode.Delay;
            usePower.defaultDuration = 100;
            usePower.initAction = delegate
            {
                this.pawn.pather.StopDead();
                workDone = 0;
            };
            usePower.tickAction = delegate
            {
                workDone++;
            };
            usePower.endConditions = new List<Func<JobCondition>>();
            usePower.AddFinishAction(delegate {
                if (workDone >= 95 && pawn.health.State==PawnHealthState.Mobile && TargetA.HasThing && !TargetA.Thing.DestroyedOrNull() && !((Pawn)TargetA.Thing).Dead)
                {
                    SoundDefOf.PsychicPulseGlobal.PlayOneShotOnCamera(this.pawn.Map);
                    HediffPsychicAwakened psychic = (HediffPsychicAwakened)this.pawn.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("PsychicAwakened"));
                    psychic.currentPower.powerClass.GetMethod("UsePower", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public).Invoke(Activator.CreateInstance(psychic.currentPower.powerClass), new object[] { psychic.currentPower, this.pawn, TargetA != LocalTargetInfo.Invalid ? (Pawn)TargetA.Thing : null });
                    if (psychic.currentPower.hostile && psychic.pawn.Faction == Faction.OfPlayer && TargetA != LocalTargetInfo.Invalid)
                    {
                        if (TargetA.Thing != null && TargetA.Thing.Faction != null)
                            TargetA.Thing.Faction.TryAffectGoodwillWith(Faction.OfPlayer, -100, reason: "Used a hostile psychic power");
                    }
                    PsychicMod.addBrainBurn(this.pawn, psychic.currentPower);
                }
            });
            yield return usePower;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look<float>(ref workDone, "WorkDone");
        }
    }
}
