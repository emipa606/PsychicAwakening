﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RimWorld
{
    public class CompUseEffect_LearnPsychicEngram : CompUseEffect
    {
        private PsychicPowerDef Power
        {
            get
            {
                return this.parent.GetComp<CompPsychicEngram>().power;
            }
        }

        public override void DoEffect(Pawn user)
        {
            base.DoEffect(user);
            PsychicPowerDef power = this.Power;
            ((HediffPsychicAwakened)user.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("PsychicAwakened"))).powersKnown.Add(power);
            if (PawnUtility.ShouldSendNotificationAbout(user))
            {
                Messages.Message("PsychicEngramUsed".Translate(user.LabelShort, power.label), user, MessageTypeDefOf.PositiveEvent, true);
            }
        }

        public override bool CanBeUsedBy(Pawn p, out string failReason)
        {
            HediffPsychicAwakened psychic = ((HediffPsychicAwakened)p.health.hediffSet.GetFirstHediffOfDef(HediffDef.Named("PsychicAwakened")));
            if (psychic==null)
            {
                failReason = "MustBePsychic".Translate(p.LabelShort);
                return false;
            }
            if (psychic.powersKnown.Contains(this.Power))
            {
                failReason = "AlreadyKnowsPower".Translate(p.LabelShort,this.Power.LabelCap);
                return false;
            }
            return base.CanBeUsedBy(p, out failReason);
        }
    }
}
