﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using Verse;

namespace RimWorld
{
    public enum PsychicTargetType
    {
        Pawn,
        Self,
        DownedPawn,
        PawnHumanlike,
        PawnOtherFaction
    }

    public class PsychicPowerDef : Def
    {
        public Type powerClass;
        public float brainBurnCost;
        public PsychicTargetType target;
        public HediffDef hediff;
        public ThoughtDef thought;
        public IncidentDef incident;
        public bool hostile = false;
        public string powerIcon;
        public virtual Texture2D Icon
        {
            get
            {
                return ContentFinder<Texture2D>.Get(powerIcon);
            }
        }
    }
}
