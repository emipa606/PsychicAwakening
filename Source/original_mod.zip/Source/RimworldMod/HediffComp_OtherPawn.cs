﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RimWorld
{
    class HediffComp_OtherPawn : HediffComp
    {
        public Pawn otherPawn = null;

        public override void CompExposeData()
        {
            Scribe_References.Look<Pawn>(ref otherPawn, "otherPawn");
        }
    }
}
