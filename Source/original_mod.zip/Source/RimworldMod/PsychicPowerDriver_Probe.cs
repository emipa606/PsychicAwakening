﻿using RimWorld.QuestGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RimWorld
{
    class PsychicPowerDriver_Probe : PsychicPowerDriver
    {
        public override void UsePower(PsychicPowerDef power, Pawn user, Pawn target)
        {
            IncidentParms questParms = new IncidentParms();
            questParms.faction = target.Faction;
            questParms.forced = true;
            questParms.target = Find.World;

            List<QuestScriptDef> possibleQuests = new List<QuestScriptDef>();
            foreach(QuestScriptDef def in DefDatabase<QuestScriptDef>.AllDefs)
            {
                if (def.IsRootRandomSelected)
                    possibleQuests.Add(def);
            }

            QuestUtility.GenerateQuestAndMakeAvailable(possibleQuests.RandomElement(), StorytellerUtility.DefaultThreatPointsNow(user.Map));
        }
    }
}
