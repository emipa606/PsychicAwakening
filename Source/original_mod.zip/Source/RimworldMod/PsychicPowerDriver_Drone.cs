﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RimWorld
{
    class PsychicPowerDriver_Drone : PsychicPowerDriver
    {
        public override void UsePower(PsychicPowerDef power, Pawn user, Pawn target)
        {
            foreach (Pawn p in user.Map.mapPawns.AllPawnsSpawned)
            {
                if (p.Faction == null || (p.Faction != user.Faction && p.Faction.HostileTo(user.Faction)))
                {
                    if (target.needs.mood != null)
                    {
                        Thought_Memory theThought = (Thought_Memory)ThoughtMaker.MakeThought(power.thought);
                        theThought.age = (int)((float)theThought.def.DurationTicks * (1 - (user.GetStatValue(StatDefOf.PsychicSensitivity) * p.GetStatValue(StatDefOf.PsychicSensitivity))));
                        theThought.moodPowerFactor = user.GetStatValue(StatDefOf.PsychicSensitivity) * p.GetStatValue(StatDefOf.PsychicSensitivity);
                        p.needs.mood.thoughts.memories.TryGainMemory(theThought, user);
                    }
                }
            }
        }
    }
}
