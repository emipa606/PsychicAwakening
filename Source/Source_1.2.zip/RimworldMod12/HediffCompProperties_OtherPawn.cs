﻿using Verse;

namespace RimWorld
{
    internal class HediffCompProperties_OtherPawn : HediffCompProperties
    {
        public HediffCompProperties_OtherPawn()
        {
            compClass = typeof(HediffComp_OtherPawn);
        }
    }
}