﻿using System.Collections.Generic;
using Verse;

namespace RimWorld
{
    public class HediffPsychicAwakened : HediffWithComps
    {
        public PsychicPowerDef currentPower;
        public List<PsychicPowerDef> powersKnown;

        public override void PostMake()
        {
            base.PostMake();
            powersKnown = new List<PsychicPowerDef>();
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref powersKnown, "powers");
            Scribe_Defs.Look(ref currentPower, "currentPower");
        }
    }
}