﻿namespace RimWorld
{
    public enum PsychicTargetType
    {
        Pawn,
        Self,
        DownedPawn,
        PawnHumanlike,
        PawnOtherFaction
    }
}