﻿using System.Collections.Generic;
using HarmonyLib;
using Verse;

namespace RimWorld
{
    [HarmonyPatch(typeof(Pawn), "GetGizmos")]
    public class PsychicPowerGizmos
    {
        [HarmonyPostfix]
        public static void GetAllTheGizmos(Pawn __instance, ref IEnumerable<Gizmo> __result)
        {
            if (__instance.IsColonistPlayerControlled)
            {
                var psychic =
                    (HediffPsychicAwakened) __instance.health.hediffSet.GetFirstHediffOfDef(
                        HediffDef.Named("PsychicAwakened"));
                if (psychic != null)
                {
                    var newList = new List<Gizmo>();
                    foreach (var g in __result)
                    {
                        newList.Add(g);
                    }

                    foreach (var power in psychic.powersKnown)
                    {
                        newList.Add(PsychicMod.generateGizmo(psychic, power));
                    }

                    __result = newList;
                }
            }
        }
    }
}